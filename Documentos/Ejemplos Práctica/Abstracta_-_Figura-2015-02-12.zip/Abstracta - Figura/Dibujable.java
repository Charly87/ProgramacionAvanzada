package figura;

public interface Dibujable
{
	public void dibujar();
}
