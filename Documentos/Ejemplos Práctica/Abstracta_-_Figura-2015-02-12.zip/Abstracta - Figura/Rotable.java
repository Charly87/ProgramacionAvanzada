package figura;

public interface Rotable
{
	public void rotar();
}
